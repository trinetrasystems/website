# Image Save Patch — Configuration Guide

All settings for image saving are in one place at the **top of `deepstream_app.c`**,
between the lines:

```
/* ========== IMAGE SAVE PATCH: configuration (edit these) ========== */
```
and
```
/* internal state */
```

---

## 1. Enable / Disable Image Saving

**Line to edit:**
```c
#define SAVE_IMG_ENABLE   1   // 1 = ON, 0 = OFF
```

Set to `0` to completely disable image saving without removing any code.

---

## 2. Output Directory (Where Images Are Saved)

**Line to edit:**
```c
#define SAVE_IMG_OUTPUT_DIR   "/home/nvidia/detected_frames"
```

- Change the path to wherever you want the JPEGs to be saved.
- The folder is **created automatically** if it does not exist.

**Example:**
```c
#define SAVE_IMG_OUTPUT_DIR   "/data/camera_snapshots"
```

---

## 3. JPEG Quality

**Line to edit:**
```c
#define SAVE_IMG_QUALITY   80
```

- Range: `1` (lowest quality, smallest file) to `100` (best quality, largest file).
- `80` is a good default.

---

## 4. Cooldown — How Often Images Are Saved

**Line to edit:**
```c
#define SAVE_IMG_COOLDOWN_FRAMES   30
```

- Minimum number of frames that must pass before saving another image **per camera**.
- At 30 fps → `30` frames ≈ 1 image per second.
- Set to `0` to save every single frame (very high disk usage).

| Value | Approx. interval at 30 fps |
|-------|---------------------------|
| 0     | Every frame                |
| 15    | ~0.5 seconds               |
| 30    | ~1 second  ← default       |
| 150   | ~5 seconds                 |
| 900   | ~30 seconds                |

---

## 5. Camera Names (Critical — Edit This!)

**Block to edit:**
```c
static const gchar *SAVE_IMG_CAMERA_NAMES[] = {
  "cam-entrance",   /* source 0 */
  "cam-parking",    /* source 1 */
  "cam-gate",       /* source 2 */
  /* add more entries for additional sources */
};
```

### Rules:
- The **index = the source ID** that DeepStream assigns to each stream.
- Source IDs start at **0** (zero-based).
- The order must match the order of your sources in the DeepStream config file.

### Example with 5 cameras:
```c
static const gchar *SAVE_IMG_CAMERA_NAMES[] = {
  "cam-entrance",    /* source 0  → 1st camera in config */
  "cam-parking",     /* source 1  → 2nd camera in config */
  "cam-gate",        /* source 2  → 3rd camera in config */
  "cam-lobby",       /* source 3  → 4th camera in config */
  "cam-server-room", /* source 4  → 5th camera in config */
};
```

### What if a camera is NOT in this list?
If your DeepStream pipeline has more sources than entries in this array,
the code **automatically falls back** to `src{id}` as the camera name.

| Source ID | In list? | Camera name in filename |
|-----------|----------|------------------------|
| 0         | ✅ Yes   | `cam-entrance`          |
| 1         | ✅ Yes   | `cam-parking`           |
| 2         | ✅ Yes   | `cam-gate`              |
| 3         | ❌ No    | `src3`  ← auto fallback |
| 7         | ❌ No    | `src7`  ← auto fallback |

> **Tip:** Always add an entry for every camera you have.
> The `SAVE_IMG_NUM_CAMERAS` macro updates automatically — no other change needed.

---

## 6. Which Object Classes Trigger a Save

**Line to edit:**
```c
static gint SAVE_IMG_TARGET_CLASSES[] = { 0 };
```

- Each number is a **class ID** from your PGIE model (same as in the labels file).
- `{ -1 }` means **save on any detection**, regardless of class.

**Examples:**
```c
static gint SAVE_IMG_TARGET_CLASSES[] = { -1 };      // ALL classes
static gint SAVE_IMG_TARGET_CLASSES[] = { 0 };        // class 0 only (e.g. person)
static gint SAVE_IMG_TARGET_CLASSES[] = { 0, 2 };     // class 0 and class 2
static gint SAVE_IMG_TARGET_CLASSES[] = { 0, 1, 2 };  // three classes
```

---

## 7. Output Filename Format

The filename is assembled in the probe function `osd_src_pad_save_prob()`
inside the block labelled:

```c
/* ---- Build filename: <camera>_<badge>_<YYYYMMDD-HHMMSS>.jpg ---- */
```

### Current format:
```
<camera>_<badge>_<YYYYMMDD-HHMMSS>.jpg
```

### Real examples:
```
cam-entrance_GOLI_20260531-143000.jpg
cam-parking_TEST-1_20260531-093015.jpg
cam-gate_WORKER-07_20260530-220045.jpg
src3_VISITOR_20260531-194600.jpg        ← camera not in list, badge = VISITOR
cam-entrance_UNKNOWN_20260531-194600.jpg ← badge label was empty
```

### Where each part comes from:

| Part              | Source                                      |
|-------------------|---------------------------------------------|
| `<camera>`        | `SAVE_IMG_CAMERA_NAMES[src_id]`             |
| `<badge>`         | `obj_label` of the first detected object    |
| `<YYYYMMDD-HHMMSS>` | System local time at the moment of capture |

### To change the timestamp format:
Find this line in `osd_src_pad_save_prob()`:
```c
strftime (ts, sizeof (ts), "%Y%m%d-%H%M%S", tm_info);
```
Edit the format string. Standard `strftime` codes apply:

| Code | Meaning  | Example |
|------|----------|---------|
| `%Y` | Year     | 2026    |
| `%m` | Month    | 05      |
| `%d` | Day      | 31      |
| `%H` | Hour 24h | 14      |
| `%M` | Minute   | 30      |
| `%S` | Second   | 00      |

**Example — change to `YYYY-MM-DD_HH-MM-SS`:**
```c
strftime (ts, sizeof (ts), "%Y-%m-%d_%H-%M-%S", tm_info);
// Result: cam-entrance_GOLI_2026-05-31_14-30-00.jpg
```

### To change the overall filename pattern:
Find this `snprintf` call (just below `strftime`):
```c
snprintf (args.fileNameImg, sizeof (args.fileNameImg) - 1,
    "%s/%s_%s_%s.jpg",
    SAVE_IMG_OUTPUT_DIR, camera_name, badge, ts);
```

The four arguments after the format string are:
1. `SAVE_IMG_OUTPUT_DIR` — the output folder
2. `camera_name`         — the camera string
3. `badge`               — the detected label
4. `ts`                  — the formatted timestamp

**Example — swap badge and camera:**
```c
snprintf (args.fileNameImg, sizeof (args.fileNameImg) - 1,
    "%s/%s_%s_%s.jpg",
    SAVE_IMG_OUTPUT_DIR, badge, camera_name, ts);
// Result: GOLI_cam-entrance_20260531-143000.jpg
```

---

## Quick Reference — All Editable Locations in `deepstream_app.c`

| What to change          | What to edit                          | ~Line |
|-------------------------|---------------------------------------|-------|
| Enable/disable saving   | `#define SAVE_IMG_ENABLE`             | 42    |
| Output folder           | `#define SAVE_IMG_OUTPUT_DIR`         | 43    |
| JPEG quality            | `#define SAVE_IMG_QUALITY`            | 44    |
| Save frequency          | `#define SAVE_IMG_COOLDOWN_FRAMES`    | 45    |
| Which classes trigger   | `SAVE_IMG_TARGET_CLASSES[]`           | 46    |
| Camera name per source  | `SAVE_IMG_CAMERA_NAMES[]`             | 51–56 |
| Timestamp format        | `strftime(...)` in probe function     | ~187  |
| Full filename pattern   | `snprintf(args.fileNameImg, ...)` in probe function | ~196  |

> All lines are approximate; use your editor's search for the exact location.

---

## How to Build and Run After Making Changes

Every time you edit `deepstream_app.c`, you must **recompile** before running.
Run these commands from inside the `deepstream-app-custom` directory:

```bash
# Step 1 — Set CUDA version (required every terminal session)
export CUDA_VER=12.6

# Step 2 — Clean old build artifacts
make clean

# Step 3 — Compile
make

# Step 4 — Run with your DeepStream config
./deepstream-app -c ~/DeepStream-Yolo/deepstream_app_config.txt
```

### Notes:
- `make clean` removes the old `.o` and binary files — always do this after
  editing `.c` files to ensure a fresh build.
- If `make` succeeds with no errors, the new binary is ready.
- The config file path (`~/DeepStream-Yolo/deepstream_app_config.txt`) is
  your specific path — adjust it if you move the config.
- `CUDA_VER` must be set **before** running `make`, not after.

### Quick one-liner (copy-paste friendly):
```bash
export CUDA_VER=12.6 && make clean && make && ./deepstream-app -c ~/DeepStream-Yolo/deepstream_app_config.txt
```

---

## 📖 Full Documentation

For complete setup, pipeline explanation, and advanced configuration,
refer to the **DeepStream Custom Docs** section on the Trinetra website:

> **Trinetra Systems → Admin Panel → Documentation → DeepStream Custom**

That page covers:
- Full pipeline architecture
- Config file reference
- Model integration
- This image-save patch in context
