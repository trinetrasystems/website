# Trinetra Image Monitor — Setup & Usage

## Dependencies (run once on Jetson)

```bash
pip3 install requests watchdog
```

## Create Required Directories (run once on Jetson)

```bash
mkdir -p /home/nvidia/script_monitor/db
mkdir -p /home/nvidia/script_monitor/logs
mkdir -p /home/nvidia/detected_frames
```

## Install systemd Service (run once on Jetson)

```bash
sudo cp /home/nvidia/script_monitor/monitor.service /etc/systemd/system/trinetra-monitor.service
sudo systemctl daemon-reload
sudo systemctl enable trinetra-monitor
sudo systemctl start trinetra-monitor
```

## Run Manually (without systemd)

```bash
python3 /home/nvidia/script_monitor/monitor.py
```

## Service Management

```bash
# Check status
sudo systemctl status trinetra-monitor

# Stop
sudo systemctl stop trinetra-monitor

# Restart
sudo systemctl restart trinetra-monitor

# Live logs
journalctl -u trinetra-monitor -f
```

## Test Notification

Drop any image into the watch folder:
```bash
cp any_image.jpg /home/nvidia/detected_frames/
```
You should receive a Telegram message within seconds.

## Config (monitor.py)

| Variable           | Description                        |
|--------------------|------------------------------------|
| `WATCH_FOLDER`     | Folder to monitor for new images   |
| `ENABLE_TELEGRAM`  | Toggle Telegram notifications      |
| `ENABLE_EMAIL`     | Toggle Email notifications         |
| `ENABLE_WHATSAPP`  | Toggle WhatsApp notifications      |
| `TG_BOT_TOKEN`     | Telegram bot token from @BotFather |
| `TG_CHAT_ID`       | Your Telegram user/chat ID         |
| `SMTP_USER`        | Gmail address                      |
| `SMTP_PASS`        | Gmail App Password (16 chars)      |
| `EMAIL_TO`         | Recipient email address            |
| `MAX_ATTEMPTS`     | Retry limit before job is parked   |
| `RETRY_INTERVAL_SEC` | Seconds between offline retries  |

## Offline Behavior

- If internet is down, notifications are queued in SQLite (`queue.db`)
- As soon as internet returns, queued notifications are sent automatically
- After `MAX_ATTEMPTS` failures, job is moved to `dead_letter` table

## Files

```
/home/nvidia/script_monitor/
├── monitor.py          # main script
├── monitor.service     # systemd service file
├── db/
│   └── queue.db        # SQLite queue (auto-created)
└── logs/
    └── notifier.log    # log file (auto-created)
```
