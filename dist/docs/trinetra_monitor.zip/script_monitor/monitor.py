#!/usr/bin/env python3
"""
Folder watcher -> Telegram / WhatsApp / Email notifier
Offline-safe, crash-safe, leak-free.
"""

import os
import time
import signal
import sqlite3
import logging
import smtplib
import socket
import threading
import mimetypes
import hashlib
from contextlib import contextmanager, closing
from email.message import EmailMessage
from pathlib import Path

import requests
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ============== CONFIG ==============
WATCH_FOLDER = "home/nvidia/detected_frames"
DB_PATH      = "/home/nvidia/script_monitor/db/queue.db"
LOG_PATH     = "/home/nvidia/script_monitor/logs/notifier.log"

ENABLE_TELEGRAM = True
ENABLE_WHATSAPP = False
ENABLE_EMAIL    = False

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

TG_BOT_TOKEN = "8628143016:AAGk6IP15OtxUnlThUNuAm0M_lTNfUdkQWE"
TG_CHAT_ID   = "959075448"

WA_PHONE_ID  = "YOUR_PHONE_NUMBER_ID"
WA_TOKEN     = "YOUR_PERMANENT_TOKEN"
WA_TO        = "919XXXXXXXXX"   # recipient with country code, no '+'

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "youremail@gmail.com"
SMTP_PASS = "your-app-password"   # Gmail App Password
EMAIL_TO  = "demo@gmail.com"

RETRY_INTERVAL_SEC = 30
SETTLE_SEC         = 1.0
MAX_ATTEMPTS       = 10       # park job in DLQ after this many failures
DEDUP_WINDOW_SEC   = 5        # ignore identical (path+size+mtime) within window
# ====================================

logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

stop_event = threading.Event()

# ---------- Queue (SQLite) ----------

@contextmanager
def db_conn():
    conn = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        yield conn
    finally:
        conn.close()

def init_db():
    with db_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                path     TEXT NOT NULL,
                channel  TEXT NOT NULL,
                attempts INTEGER DEFAULT 0,
                created  REAL DEFAULT (strftime('%s','now')),
                dedup_key TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS dead_letter (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                path       TEXT,
                channel    TEXT,
                attempts   INTEGER,
                last_error TEXT,
                parked_at  REAL DEFAULT (strftime('%s','now'))
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_dedup ON jobs(dedup_key);")

def make_dedup_key(path: str) -> str:
    try:
        st = os.stat(path)
        raw = f"{path}|{st.st_size}|{int(st.st_mtime)}"
    except OSError:
        raw = path
    return hashlib.sha1(raw.encode()).hexdigest()

def enqueue(path: str):
    key    = make_dedup_key(path)
    cutoff = time.time() - DEDUP_WINDOW_SEC

    channels = []
    if ENABLE_TELEGRAM: channels.append("telegram")
    if ENABLE_WHATSAPP: channels.append("whatsapp")
    if ENABLE_EMAIL:    channels.append("email")

    if not channels:
        return

    with db_conn() as conn:
        existing = conn.execute(
            "SELECT 1 FROM jobs WHERE dedup_key=? AND created>=? LIMIT 1",
            (key, cutoff),
        ).fetchone()
        if existing:
            logging.info("Dedup skip: %s", path)
            return
        for ch in channels:
            conn.execute(
                "INSERT INTO jobs(path,channel,dedup_key) VALUES(?,?,?)",
                (path, ch, key),
            )
    logging.info("Queued: %s (%d channel(s))", path, len(channels))

# ---------- Connectivity ----------

def online() -> bool:
    try:
        with closing(socket.create_connection(("1.1.1.1", 53), timeout=3)):
            return True
    except OSError:
        return False

# ---------- Senders ----------

def send_telegram(path: str) -> bool:
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendPhoto"
    with open(path, "rb") as f:
        r = requests.post(
            url,
            data={"chat_id": TG_CHAT_ID,
                  "caption": f"New image: {os.path.basename(path)}"},
            files={"photo": f},
            timeout=30,
        )
    if r.status_code != 200:
        raise RuntimeError(f"telegram {r.status_code}: {r.text[:200]}")
    return True

def send_whatsapp(path: str) -> bool:
    mime, _ = mimetypes.guess_type(path)
    mime = mime or "image/jpeg"

    with open(path, "rb") as f:
        up = requests.post(
            f"https://graph.facebook.com/v20.0/{WA_PHONE_ID}/media",
            headers={"Authorization": f"Bearer {WA_TOKEN}"},
            files={"file": (os.path.basename(path), f, mime)},
            data={"messaging_product": "whatsapp", "type": mime},
            timeout=30,
        )
    if up.status_code != 200:
        raise RuntimeError(f"wa upload {up.status_code}: {up.text[:200]}")
    media_id = up.json()["id"]

    r = requests.post(
        f"https://graph.facebook.com/v20.0/{WA_PHONE_ID}/messages",
        headers={"Authorization": f"Bearer {WA_TOKEN}",
                 "Content-Type": "application/json"},
        json={"messaging_product": "whatsapp", "to": WA_TO,
              "type": "image",
              "image": {"id": media_id,
                        "caption": f"New: {os.path.basename(path)}"}},
        timeout=30,
    )
    if r.status_code != 200:
        raise RuntimeError(f"wa send {r.status_code}: {r.text[:200]}")
    return True

def send_email(path: str) -> bool:
    mime, _ = mimetypes.guess_type(path)
    if mime and mime.startswith("image/"):
        maintype, subtype = mime.split("/", 1)
    else:
        maintype, subtype = "application", "octet-stream"

    msg = EmailMessage()
    msg["Subject"] = f"New image: {os.path.basename(path)}"
    msg["From"]    = SMTP_USER
    msg["To"]      = EMAIL_TO
    msg.set_content(f"Captured: {path}")
    with open(path, "rb") as f:
        msg.add_attachment(
            f.read(), maintype=maintype, subtype=subtype,
            filename=os.path.basename(path),
        )
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as s:
        s.starttls()
        s.login(SMTP_USER, SMTP_PASS)
        s.send_message(msg)
    return True

SENDERS = {
    "telegram": send_telegram,
    "whatsapp": send_whatsapp,
    "email":    send_email,
}

# ---------- Worker ----------

def park_dead_letter(conn, jid: int, path: str, channel: str,
                     attempts: int, err: str):
    # FIX 1: explicit transaction so INSERT + DELETE are atomic.
    # With isolation_level=None (autocommit), we must manage BEGIN/COMMIT
    # ourselves to prevent a crash leaving the job in both tables.
    conn.execute("BEGIN")
    try:
        conn.execute(
            "INSERT INTO dead_letter(path,channel,attempts,last_error)"
            " VALUES(?,?,?,?)",
            (path, channel, attempts, err[:500]),
        )
        conn.execute("DELETE FROM jobs WHERE id=?", (jid,))
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    logging.error("Parked DLQ: id=%d ch=%s path=%s err=%s", jid, channel, path, err)

def worker():
    while not stop_event.is_set():
        try:
            if not online():
                stop_event.wait(RETRY_INTERVAL_SEC)
                continue

            with db_conn() as conn:
                rows = conn.execute(
                    "SELECT id,path,channel,attempts FROM jobs"
                    " WHERE attempts < ? ORDER BY id LIMIT 20",
                    (MAX_ATTEMPTS,),
                ).fetchall()

            if not rows:
                stop_event.wait(2)
                continue

            # FIX 1 (cont): open a fresh connection per-job so the
            # DB is not held open across slow network calls.
            for jid, path, channel, attempts in rows:
                if not os.path.exists(path):
                    with db_conn() as conn:
                        conn.execute("DELETE FROM jobs WHERE id=?", (jid,))
                    logging.warning("File gone, dropping job %d: %s", jid, path)
                    continue
                try:
                    SENDERS[channel](path)
                    with db_conn() as conn:
                        conn.execute("DELETE FROM jobs WHERE id=?", (jid,))
                    logging.info("Sent %s: %s", channel, path)
                except Exception as e:
                    new_attempts = attempts + 1
                    with db_conn() as conn:
                        if new_attempts >= MAX_ATTEMPTS:
                            park_dead_letter(conn, jid, path, channel,
                                             new_attempts, str(e))
                        else:
                            conn.execute(
                                "UPDATE jobs SET attempts=? WHERE id=?",
                                (new_attempts, jid),
                            )
                    logging.warning("Send fail %s %s (attempt %d/%d): %s",
                                    channel, path, new_attempts, MAX_ATTEMPTS, e)

            stop_event.wait(1)

        except Exception:
            logging.exception("Worker loop error")
            stop_event.wait(5)

# ---------- Watcher ----------

class Handler(FileSystemEventHandler):

    def _settle_and_enqueue(self, path: str):
        """Run in its own thread — does NOT block the watchdog event thread."""
        ext = Path(path).suffix.lower()
        if ext not in IMAGE_EXTS:
            return
        # wait for file write to finish (size stable)
        last = -1
        for _ in range(20):
            try:
                cur = os.path.getsize(path)
            except OSError:
                return
            if cur == last and cur > 0:
                break
            last = cur
            time.sleep(SETTLE_SEC)
        enqueue(path)

    def on_created(self, event):
        # FIX 2: spawn thread so watchdog event loop is never blocked.
        if not event.is_directory:
            threading.Thread(
                target=self._settle_and_enqueue,
                args=(event.src_path,),
                daemon=True,
            ).start()

    def on_moved(self, event):
        # handles atomic-rename pattern (write to .tmp then mv to .jpg)
        if not event.is_directory:
            threading.Thread(
                target=self._settle_and_enqueue,
                args=(event.dest_path,),
                daemon=True,
            ).start()

# ---------- Main ----------

def main():
    # FIX 3: handle SIGTERM (sent by systemctl stop) for graceful shutdown.
    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())

    os.makedirs(WATCH_FOLDER, exist_ok=True)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    init_db()

    threading.Thread(target=worker, daemon=True).start()

    obs = Observer()
    obs.schedule(Handler(), WATCH_FOLDER, recursive=False)
    obs.start()
    logging.info("Watching %s", WATCH_FOLDER)

    try:
        stop_event.wait()           # blocks until SIGTERM or KeyboardInterrupt
    except KeyboardInterrupt:
        pass
    finally:
        stop_event.set()
        obs.stop()
        obs.join()
        logging.info("Shutdown complete.")

if __name__ == "__main__":
    main()
